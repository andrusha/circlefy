#!/usr/bin/python
"""\
@file   __init__.py
@author Nat Goodspeed
@date   2008-03-18
@brief  Make eventlet.support a subpackage

$LicenseInfo:firstyear=2008&license=internal$
Copyright (c) 2008, Linden Research, Inc.
$/LicenseInfo$
"""


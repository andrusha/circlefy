from wsgi import format_date_time
import warnings
warnings.warn("httpdate module is deprecated; its contents is moved to wsgi.py", DeprecationWarning, stacklevel=2)

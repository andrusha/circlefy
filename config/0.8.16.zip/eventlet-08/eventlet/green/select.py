__select = __import__('select')
error = __select.error
from eventlet.api import select
